# -*- coding:utf-8 -*-

import urllib
import urllib2

'''

url = 'http://blog.sina.com.cn/s/blog_175b6d13b0102xykg.html'

req = urllib2.Request(url)
res = urllib2.urlopen(req)

print res.read()

'''

url = 'http://comet.blog.sina.com.cn/api?maintype=hits&act=4&aid=175b6d13b0102xykg&ref=http%3A%2F%2Fblog.sina.com.cn%2Fs%2Farticlelist_6269882683_0_1.html&varname=requestId_58884373'

# cookie = 'EditorToolType=base; _s_loginuid=6269882683; SINAGLOBAL=106.39.41.170_1496504418.867980; UOR=www.baidu.com,www.sina.com.cn,; SGUID=1496648001029_78295224; SCF=AouQMZqfLW3ISxVaCaucj0izlJP1kzjsg3SJG7h-3njTsAijR66WrZC3K5DaOO3CxCgzyNrXCRuiKxh-Fg0vMn4.; U_TRS1=000000ea.e295473b.593579d3.48749d72; lxlrtst=1496805761_o; _s_loginStatus=6269882683; lxlrttp=1496894899; BLOGUSERNNNNAME=undefined; LiRe=true; onceloggedonblog=1497196800000; sso_info=v02m6alo5qztYOcpr24noKVhY2SlLiNkpS4joKVhY2ylLmNgpS5kaKZtZqWkL2No4i2jpOguIyjmLiMsMDA; U_TRS2=00000092.8e446d7c.593e2c17.5013acdf; SUB=_2A250OlxIDeRhGeBM7VsZ-CzKwz-IHXVXTsqArDV_PUNbm9BeLUX4kW8iv2cstqS1FKMkjddE94Mod_6ISA..; SUBP=0033WrSXqPxfM725Ws9jqgMF55529P9D9WhEIYOO8yZxjor5Wjdi_OFg5NHD95Qceoq41hnESon0Ws4DqcjPBNiawGnLxK-L1h-L1hnLxKML1KBL1-qt; ALF=1528782744; SessionID=14na9vk85ciqm1oa1ku67kguc1; IDC_LOGIN=BJ%3A1497246744; SINABLOGNUINFO=6269882683.175b6d13b.; rotatecount=1; Apache=106.39.41.146_1497246745.544294; BLOG_TITLE=Croxx%E5%85%88%E7%94%9F%E7%9A%84%E5%8D%9A%E5%AE%A2; ULV=1497246746448:24:24:8:106.39.41.146_1497246745.544294:1497246742582'

headers = {
		
	"Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
	"Accept-Encoding":"gzip, deflate",
	"Accept-Language":"zh-CN,zh;q=0.8",
	"Cache-Control":"max-age=0",
	"Connection":"keep-alive",

	"Content-Type":"application/x-www-form-urlencoded",
	"Cookie":'',
	"Host":"control.blog.sina.com.cn",
	"Origin":"http://control.blog.sina.com.cn",
	"Referer":"http://control.blog.sina.com.cn/admin/article/article_add.php",
	"Upgrade-Insecure-Requests":"1",
	"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36",

	}
for i in range(10):
	req = urllib2.Request(url,headers=headers)
	res = urllib2.urlopen(req)


