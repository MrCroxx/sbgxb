# -*- coding:utf-8 -*-
import scrapy
from con4sinablog.items import Con4SinablogItem
from scrapy.contrib.spiders import Rule,CrawlSpider
from scrapy.contrib.linkextractors import LinkExtractor

class ChinaDailySpider(CrawlSpider):
	name = "chinadaily"
	allowed_domains = ['www.chinadaily.com.cn']


	start_urls = [
		'http://www.chinadaily.com.cn/china/governmentandpolicy.html'
	]

	rules = [
		#Rule(LinkExtractor(allow=(r"content_[0-9]+\.htm",)),callback='parse_item'),
		
		Rule(LinkExtractor(allow=r"http://www.chinadaily.com.cn/china/.+/content_[0-9]+.htm"),'parse_item'),
		Rule(LinkExtractor(allow=r"http://www.chinadaily.com.cn/china/.*")),
	]

	# http://www.chinadaily.com.cn/world/cn_eu/2017-06/03/content_29606003.htm
	# http://www.chinadaily.com.cn/china/2017-06/03/content_29606057.htm

	def parse_item(self,response):

		self.log('Hi, this is an item page! %s' % response.url)
		item = Con4SinablogItem()
		item['title']=response.xpath("//div[@class='lft_art']/h1/text()").extract()
		item['info']=response.xpath("//span[@class='info_l']/text()").extract()
		item['content']=response.xpath("//div[@id='Content']/p/text()").extract()


		if item['title'] != [] and item['info'] != [] and item['content'] != []:
			return item
